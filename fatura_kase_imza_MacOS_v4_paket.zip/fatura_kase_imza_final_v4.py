#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import sys, tempfile, subprocess, shutil, urllib.parse, json, re, html as html_lib, unicodedata
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime

try:
    import fitz
except ImportError:
    root = tk.Tk()
    root.withdraw()
    messagebox.showerror("Eksik paket", "PyMuPDF eksik.\n\nKurulum scriptiyle yeniden app oluştur.")
    sys.exit(1)

try:
    from weasyprint import HTML, CSS
except Exception:
    HTML = None
    CSS = None


APP_NAME = "FaturaKaseImza"
CONFIG_DIR = Path.home() / "Library" / "Application Support" / APP_NAME
CONFIG_FILE = CONFIG_DIR / "config.json"
DEFAULT_OUTPUT_ROOT = Path.home() / "Desktop"

DEFAULT_X, DEFAULT_Y, DEFAULT_W, DEFAULT_H = 225, 210, 200, 85

HTML_SCALE = 0.92
HTML_SAFE_MARGIN_MM = 5


def find_browser():
    candidates = [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        shutil.which("google-chrome"),
        shutil.which("chromium"),
        shutil.which("microsoft-edge"),
    ]
    for c in candidates:
        if c and Path(c).exists():
            return str(c)
    return None


def file_url(path: Path) -> str:
    return "file://" + urllib.parse.quote(str(path.resolve()))


def inject_a4_fit_css(html_path: Path) -> Path:
    raw = html_path.read_text(encoding="utf-8", errors="ignore")

    css = f"""
<style id="fatura-kase-a4-fix">
@page {{
    size: A4;
    margin: 0;
}}
html {{
    width: 210mm !important;
    min-height: 297mm !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: visible !important;
}}
body {{
    width: 210mm !important;
    min-height: 297mm !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: visible !important;
    background: white !important;
    padding-left: {HTML_SAFE_MARGIN_MM}mm !important;
    padding-top: {HTML_SAFE_MARGIN_MM}mm !important;
    box-sizing: border-box !important;
}}
body > * {{
    transform: scale({HTML_SCALE}) !important;
    transform-origin: top left !important;
}}
table, div, section, article {{
    max-width: 100% !important;
}}
</style>
"""
    lower = raw.lower()
    if "</head>" in lower:
        idx = lower.find("</head>")
        raw = raw[:idx] + css + raw[idx:]
    else:
        raw = css + raw

    temp_html = Path(tempfile.gettempdir()) / f"{html_path.stem}_a4_fit_print.html"
    temp_html.write_text(raw, encoding="utf-8")
    return temp_html


def tr_ascii(s: str) -> str:
    table = str.maketrans({
        "ç": "c", "Ç": "C",
        "ğ": "g", "Ğ": "G",
        "ı": "i", "İ": "I",
        "ö": "o", "Ö": "O",
        "ş": "s", "Ş": "S",
        "ü": "u", "Ü": "U",
    })
    s = s.translate(table)
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return s


def safe_filename(name: str) -> str:
    name = html_lib.unescape(name or "")
    name = name.replace("\xa0", " ")
    name = re.sub(r"\s+", " ", name).strip()
    name = tr_ascii(name)
    name = re.sub(r"[^A-Za-z0-9 _.-]", "", name)
    name = re.sub(r"\s+", "_", name).strip("._- ")
    return name or "fatura"


def html_to_plain_text(html_path: Path) -> str:
    raw = html_path.read_text(encoding="utf-8", errors="ignore")
    raw = re.sub(r"<br\s*/?>", "\n", raw, flags=re.I)
    raw = re.sub(r"</tr\s*>", "\n", raw, flags=re.I)
    raw = re.sub(r"</td\s*>", " ", raw, flags=re.I)
    raw = re.sub(r"<script\b[^>]*>.*?</script>", " ", raw, flags=re.I | re.S)
    raw = re.sub(r"<style\b[^>]*>.*?</style>", " ", raw, flags=re.I | re.S)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = html_lib.unescape(raw)
    raw = raw.replace("\xa0", " ")
    raw = re.sub(r"[ \t\r\f\v]+", " ", raw)
    raw = re.sub(r"\n\s*", "\n", raw)
    return raw.strip()


def extract_customer_name_from_html(html_path: Path) -> str:
    """
    GİB/Trendyol e-Arşiv HTML şablonunda alıcı adı genelde SAYIN satırından hemen sonra gelir.
    Örnek:
      SAYIN Halis Karadağ Yemişli sk...
    Bu fonksiyon adres başlamadan önceki isim bölümünü almaya çalışır.
    """
    text = html_to_plain_text(html_path)
    one_line = re.sub(r"\s+", " ", text)

    m = re.search(r"\bSAYIN\s+(.+?)(?:\s+(?:Mah\.?|Mahallesi|Cad\.?|Caddesi|Sok\.?|Sokağı|Sk\.?|No:|Kapı|Türkiye|Web Sitesi|E-Posta|Tel:|Fax:|TCKN:|VKN:))", one_line, flags=re.I)
    if not m:
        m = re.search(r"\bSAYIN\s+(.{2,80})", one_line, flags=re.I)

    if not m:
        return ""

    candidate = m.group(1).strip()

    # Çok uzarsa ilk 2-4 kelimeyi al. Kişi/şirket adları için yeterli.
    words = candidate.split()
    stop_words = {
        "mah", "mah.", "mahallesi", "cad", "cad.", "caddesi", "sok", "sok.", "sokağı",
        "sk", "sk.", "no", "no:", "kapı", "kapi", "türkiye", "turkiye", "web", "sitesi",
        "e-posta", "tel", "fax", "tckn", "vkn"
    }

    clean_words = []
    for w in words:
        if w.strip().lower() in stop_words:
            break
        if len(clean_words) >= 4:
            break
        clean_words.append(w)

    # En az iki kelime varsa kişi adı için daha güvenli.
    if len(clean_words) >= 2:
        return " ".join(clean_words)

    return candidate


class StampApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Fatura Kaşe/İmza")
        self.root.geometry("780x585")
        self.root.resizable(False, False)

        CONFIG_DIR.mkdir(parents=True, exist_ok=True)

        self.files = []
        self.config = self.load_config()

        self.stamp_path = Path(self.config.get("stamp_path", ""))
        self.output_root = Path(self.config.get("output_root", str(DEFAULT_OUTPUT_ROOT)))

        self.x_var = tk.StringVar(value=str(self.config.get("x", DEFAULT_X)))
        self.y_var = tk.StringVar(value=str(self.config.get("y", DEFAULT_Y)))
        self.w_var = tk.StringVar(value=str(self.config.get("w", DEFAULT_W)))
        self.h_var = tk.StringVar(value=str(self.config.get("h", DEFAULT_H)))
        self.status_var = tk.StringVar(value="Hazır.")

        self.build_ui()
        self.refresh_settings_labels()

        if not self.stamp_path.exists() or not self.output_root.exists():
            self.root.after(400, self.first_setup)

    def load_config(self):
        if CONFIG_FILE.exists():
            try:
                return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            except Exception:
                return {}
        return {}

    def save_config(self):
        try:
            self.config.update({
                "stamp_path": str(self.stamp_path),
                "output_root": str(self.output_root),
                "x": float(self.x_var.get() or DEFAULT_X),
                "y": float(self.y_var.get() or DEFAULT_Y),
                "w": float(self.w_var.get() or DEFAULT_W),
                "h": float(self.h_var.get() or DEFAULT_H),
            })
            CONFIG_FILE.write_text(json.dumps(self.config, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def build_ui(self):
        pad = 14

        tk.Label(self.root, text="Fatura PDF/HTML Dosyalarına Kaşe/İmza Ekle", font=("Arial", 16, "bold")).pack(pady=(18, 6))
        tk.Label(self.root, text="HTML faturada alıcı adı dosya ismi yapılır. Kaşe/imza ve çıktı klasörü hatırlanır.", font=("Arial", 11)).pack(pady=(0, 8))

        html_ok = "HTML desteği aktif. Alıcı adı dosya adına yazılır." if (HTML or find_browser()) else "HTML için Google Chrome kurulu olmalı."
        tk.Label(self.root, text=html_ok, font=("Arial", 10), fg=("black" if (HTML or find_browser()) else "red")).pack(pady=(0, 10))

        settings_frame = tk.LabelFrame(self.root, text="Kayıtlı ayarlar")
        settings_frame.pack(fill="x", padx=pad, pady=(0, 10))

        self.stamp_label = tk.Label(settings_frame, text="", anchor="w", font=("Arial", 10), wraplength=720, justify="left")
        self.stamp_label.pack(fill="x", padx=8, pady=(8, 2))

        self.output_label = tk.Label(settings_frame, text="", anchor="w", font=("Arial", 10), wraplength=720, justify="left")
        self.output_label.pack(fill="x", padx=8, pady=(2, 8))

        settings_btn_frame = tk.Frame(self.root)
        settings_btn_frame.pack(pady=(0, 12))

        tk.Button(settings_btn_frame, text="Kaşe/İmza Seç ve Kaydet", width=24, height=2, command=self.select_stamp).grid(row=0, column=0, padx=8)
        tk.Button(settings_btn_frame, text="Çıktı Klasörü Seç ve Kaydet", width=26, height=2, command=self.select_output_folder).grid(row=0, column=1, padx=8)
        tk.Button(settings_btn_frame, text="Ayarları Sıfırla", width=18, height=2, command=self.reset_settings).grid(row=0, column=2, padx=8)

        file_btn_frame = tk.Frame(self.root)
        file_btn_frame.pack(pady=(0, 12))

        tk.Button(file_btn_frame, text="Fatura Dosyaları Seç", width=24, height=2, command=self.select_files).grid(row=0, column=0, padx=8)
        tk.Button(file_btn_frame, text="Fatura Klasörü Seç", width=24, height=2, command=self.select_folder).grid(row=0, column=1, padx=8)

        selected_frame = tk.LabelFrame(self.root, text="Seçilen faturalar (.pdf, .html, .htm)")
        selected_frame.pack(fill="both", expand=False, padx=pad, pady=(0, 10))
        self.listbox = tk.Listbox(selected_frame, height=8)
        self.listbox.pack(fill="both", padx=8, pady=8)

        pos_frame = tk.LabelFrame(self.root, text="Konum ve boyut ayarı")
        pos_frame.pack(fill="x", padx=pad, pady=(0, 12))

        labels = [("Soldan", self.x_var), ("Üstten", self.y_var), ("Genişlik", self.w_var), ("Yükseklik", self.h_var)]
        for i, (label, var) in enumerate(labels):
            tk.Label(pos_frame, text=label).grid(row=0, column=i*2, padx=(10, 4), pady=10)
            tk.Entry(pos_frame, textvariable=var, width=7).grid(row=0, column=i*2+1, padx=(0, 10), pady=10)

        tk.Button(self.root, text="Kaşe/İmza Ekle", font=("Arial", 13, "bold"), height=2, command=self.process).pack(fill="x", padx=pad)

        tk.Label(self.root, textvariable=self.status_var, anchor="w", font=("Arial", 10), wraplength=740, justify="left").pack(fill="x", padx=pad, pady=(10, 0))

    def refresh_settings_labels(self):
        self.stamp_label.config(text=f"Kaşe/imza: {self.stamp_path}" if self.stamp_path.exists() else "Kaşe/imza: kayıtlı değil")
        self.output_label.config(text=f"Çıktı klasörü: {self.output_root}" if self.output_root.exists() else "Çıktı klasörü: kayıtlı değil")

    def first_setup(self):
        if not self.stamp_path.exists():
            messagebox.showinfo("İlk kurulum", "Önce kaşe/imza görselini seç.\n\nBu seçim kaydedilecek.")
            self.select_stamp()
        if not self.output_root.exists():
            self.output_root = DEFAULT_OUTPUT_ROOT
        messagebox.showinfo("Çıktı klasörü", "Şimdi kaşeli faturaların kaydedileceği klasörü seç.\n\nBu seçim kaydedilecek.")
        self.select_output_folder()

    def select_stamp(self):
        file = filedialog.askopenfilename(title="Kaşe/imza görselini seç", filetypes=[("Görsel dosyaları", "*.png *.jpg *.jpeg")])
        if file:
            src = Path(file)
            target = CONFIG_DIR / ("kase_imza" + src.suffix.lower())
            shutil.copy2(src, target)
            self.stamp_path = target
            self.save_config()
            self.refresh_settings_labels()
            self.status_var.set("Kaşe/imza kaydedildi.")

    def select_output_folder(self):
        folder = filedialog.askdirectory(title="Kaşeli faturaların kaydedileceği klasörü seç", initialdir=str(self.output_root if self.output_root.exists() else DEFAULT_OUTPUT_ROOT))
        if folder:
            self.output_root = Path(folder)
            self.save_config()
            self.refresh_settings_labels()
            self.status_var.set("Çıktı klasörü kaydedildi.")

    def reset_settings(self):
        if not messagebox.askyesno("Ayarları sıfırla", "Kaşe/imza, çıktı klasörü ve konum ayarları sıfırlansın mı?"):
            return
        try:
            if CONFIG_FILE.exists():
                CONFIG_FILE.unlink()
        except Exception:
            pass
        self.config = {}
        self.stamp_path = Path("")
        self.output_root = DEFAULT_OUTPUT_ROOT
        self.x_var.set(str(DEFAULT_X)); self.y_var.set(str(DEFAULT_Y)); self.w_var.set(str(DEFAULT_W)); self.h_var.set(str(DEFAULT_H))
        self.refresh_settings_labels()
        self.status_var.set("Ayarlar sıfırlandı.")

    def select_files(self):
        files = filedialog.askopenfilenames(title="Fatura dosyalarını seç", filetypes=[("Fatura dosyaları", "*.pdf *.html *.htm"), ("PDF", "*.pdf"), ("HTML", "*.html *.htm")])
        if files:
            self.files = [Path(f) for f in files]
            self.refresh_file_list()

    def select_folder(self):
        folder = filedialog.askdirectory(title="Faturaların olduğu klasörü seç")
        if folder:
            folder = Path(folder)
            self.files = sorted(list(folder.glob("*.pdf")) + list(folder.glob("*.html")) + list(folder.glob("*.htm")))
            self.refresh_file_list()

    def refresh_file_list(self):
        self.listbox.delete(0, tk.END)
        for f in self.files:
            self.listbox.insert(tk.END, f.name)
        self.status_var.set(f"{len(self.files)} fatura seçildi.")

    def output_dir(self):
        return self.output_root / f"Kaselenmis_Faturalar_{datetime.now().strftime('%m-%d')}"

    def output_file(self, original):
        today = datetime.now().strftime("%m-%d")
        suffix = original.suffix.lower()

        if suffix in [".html", ".htm"]:
            customer = extract_customer_name_from_html(original)
            base = safe_filename(customer) if customer else safe_filename(original.stem)
            return self.output_dir() / f"{base}_{today}.pdf"

        return self.output_dir() / f"{original.stem}_kaseli_imzali_{today}.pdf"

    def unique_output_file(self, path: Path) -> Path:
        if not path.exists():
            return path
        stem, suffix = path.stem, path.suffix
        i = 2
        while True:
            candidate = path.with_name(f"{stem}_{i}{suffix}")
            if not candidate.exists():
                return candidate
            i += 1

    def get_rect(self):
        try:
            x, y, w, h = float(self.x_var.get()), float(self.y_var.get()), float(self.w_var.get()), float(self.h_var.get())
        except ValueError:
            raise ValueError("Konum/boyut alanlarına sadece sayı gir.")
        self.save_config()
        return fitz.Rect(x, y, x + w, y + h)

    def html_to_pdf_weasy(self, html_path):
        temp_pdf = Path(tempfile.gettempdir()) / f"{html_path.stem}_a4_weasy_fit.pdf"
        css = CSS(string=f"""
            @page {{ size: A4; margin: {HTML_SAFE_MARGIN_MM}mm; }}
            html, body {{ margin:0; padding:0; width:200mm; min-height:287mm; overflow: visible; }}
            body > * {{ transform: scale({HTML_SCALE}); transform-origin: top left; }}
        """)
        HTML(filename=str(html_path)).write_pdf(str(temp_pdf), stylesheets=[css])
        return temp_pdf

    def html_to_pdf_browser(self, html_path):
        browser = find_browser()
        if not browser:
            raise RuntimeError("HTML için Google Chrome kurulu değil ve WeasyPrint çalışmadı.")
        temp_html = inject_a4_fit_css(html_path)
        temp_pdf = Path(tempfile.gettempdir()) / f"{html_path.stem}_a4_chrome_fit.pdf"
        if temp_pdf.exists():
            temp_pdf.unlink()

        cmd = [
            browser,
            "--headless",
            "--disable-gpu",
            "--no-pdf-header-footer",
            "--print-to-pdf=" + str(temp_pdf),
            file_url(temp_html),
        ]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=60)
        if not temp_pdf.exists() or temp_pdf.stat().st_size == 0:
            raise RuntimeError("HTML PDF'e çevrilemedi: " + result.stderr[:800])
        return temp_pdf

    def normalize_to_a4(self, pdf_path):
        src = fitz.open(pdf_path)
        out = fitz.open()
        a4 = fitz.Rect(0, 0, 595, 842)
        for p in src:
            page = out.new_page(width=a4.width, height=a4.height)
            margin = 8
            target = fitz.Rect(margin, margin, a4.width - margin, a4.height - margin)
            page.show_pdf_page(target, src, p.number, keep_proportion=True)
        normalized = Path(tempfile.gettempdir()) / f"{Path(pdf_path).stem}_normalized_a4.pdf"
        out.save(normalized, deflate=True, garbage=4)
        src.close(); out.close()
        return normalized

    def html_to_pdf(self, html_path):
        generated = None
        if HTML:
            try:
                generated = self.html_to_pdf_weasy(html_path)
            except Exception:
                generated = None
        if generated is None:
            generated = self.html_to_pdf_browser(html_path)
        return self.normalize_to_a4(generated)

    def stamp_pdf(self, source_pdf, output_pdf, rect):
        doc = fitz.open(source_pdf)
        if len(doc) == 0:
            doc.close()
            raise ValueError("Boş PDF")
        doc[0].insert_image(rect, filename=str(self.stamp_path), keep_proportion=True, overlay=True)
        output_pdf.parent.mkdir(parents=True, exist_ok=True)
        output_pdf = self.unique_output_file(output_pdf)
        doc.save(output_pdf, deflate=True, garbage=4)
        doc.close()
        return output_pdf

    def process_one(self, file_path, rect):
        suffix = file_path.suffix.lower()
        if suffix == ".pdf":
            source_pdf = file_path
        elif suffix in [".html", ".htm"]:
            source_pdf = self.html_to_pdf(file_path)
        else:
            raise ValueError("Desteklenmeyen dosya tipi")
        out = self.output_file(file_path)
        return self.stamp_pdf(source_pdf, out, rect)

    def process(self):
        if not self.stamp_path.exists():
            messagebox.showerror("Kaşe/imza yok", "Önce 'Kaşe/İmza Seç ve Kaydet' butonuyla kaşe görselini seç.")
            return
        if not self.output_root.exists():
            messagebox.showerror("Çıktı klasörü yok", "Önce 'Çıktı Klasörü Seç ve Kaydet' butonuyla çıktı klasörü seç.")
            return
        if not self.files:
            messagebox.showwarning("Fatura seçilmedi", "Önce PDF/HTML dosyası veya klasör seç.")
            return

        try:
            rect = self.get_rect()
        except Exception as e:
            messagebox.showerror("Hatalı ayar", str(e))
            return

        ok, failed = 0, []
        for f in self.files:
            try:
                self.process_one(f, rect)
                ok += 1
            except Exception as e:
                failed.append(f"{f.name}: {e}")

        outdir = self.output_dir()
        if failed:
            messagebox.showwarning("Kısmen tamamlandı", f"{ok} fatura işlendi.\n\nÇıktı:\n{outdir}\n\nHata:\n" + "\n\n".join(failed[:10]))
        else:
            messagebox.showinfo("Tamamlandı", f"{ok} fatura işlendi.\n\nÇıktılar:\n{outdir}")
        self.status_var.set(f"Tamamlandı. {ok} fatura işlendi. Çıktı: {outdir}")


def main():
    root = tk.Tk()
    StampApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
