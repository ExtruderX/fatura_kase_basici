#!/bin/bash
set -e

APP_NAME="Fatura Kase Imza"
MAIN_FILE="fatura_kase_imza_final_v4.py"

cd "$(dirname "$0")"

echo "Paketler kuruluyor..."
python3 -m pip install --upgrade pip
python3 -m pip install pymupdf pyinstaller
python3 -m pip install weasyprint || true

echo "Eski build temizleniyor..."
rm -rf build dist "${APP_NAME}.spec"

echo "App oluşturuluyor..."
python3 -m PyInstaller \
  --windowed \
  --name "$APP_NAME" \
  --hidden-import=weasyprint \
  "$MAIN_FILE"

echo ""
echo "Bitti:"
echo "$(pwd)/dist/${APP_NAME}.app"
