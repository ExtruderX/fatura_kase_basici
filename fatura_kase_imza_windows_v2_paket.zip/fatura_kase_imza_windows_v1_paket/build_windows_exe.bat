@echo off
setlocal

set APP_NAME=Fatura Kase Imza
set MAIN_FILE=fatura_kase_imza_windows_v1.py

echo Paketler kuruluyor...
py -m pip install --upgrade pip
py -m pip install pymupdf pyinstaller
py -m pip install weasyprint

echo Eski build temizleniyor...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "%APP_NAME%.spec" del "%APP_NAME%.spec"

echo EXE olusturuluyor...
py -m PyInstaller --windowed --onefile --name "%APP_NAME%" --hidden-import=weasyprint "%MAIN_FILE%"

echo.
echo Bitti:
echo dist\%APP_NAME%.exe
echo.
echo Bu exe dosyasini Masaustu'ne veya istedigin klasore kopyalayabilirsin.
echo Ilk acilista kase/imza ve cikti klasoru secilecek. Sonra hatirlayacak.
pause
