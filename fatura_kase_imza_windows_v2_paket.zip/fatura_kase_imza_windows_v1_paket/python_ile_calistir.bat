@echo off
py fatura_kase_imza_windows_v1.py
pause
